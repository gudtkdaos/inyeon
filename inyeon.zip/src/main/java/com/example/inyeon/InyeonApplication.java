package com.example.inyeon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InyeonApplication {

    public static void main(String[] args) {
        SpringApplication.run(InyeonApplication.class, args);

    } // end of main()

}  // end of class
