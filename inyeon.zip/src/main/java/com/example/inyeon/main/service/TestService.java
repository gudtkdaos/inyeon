package com.example.inyeon.main.service;

import com.example.inyeon.main.dto.TestDTO;

import java.util.List;

public interface TestService {
    public List<TestDTO> selectTest();

}
