package com.example.inyeon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InyeonApplicationTests {

    @Test
    void contextLoads() {
    }

}
